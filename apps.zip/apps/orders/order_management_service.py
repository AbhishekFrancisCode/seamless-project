from apps.orders.models import Orders


class OrderService:

    @classmethod
    def get_order(cls, id):
        order = Orders.objects.filter(id=id).values(
            'id',
            'order_type',
            'customer__customer_name',
            'dealer__dealer_name',
            'order_date',
            'order_time',
            'entries',
            'customer_contact_no',
            'chassiss_number',
            'application_number',
            'rto__rto_name',
            'remarks',
            'status',

            # New vehicle fields
            'reg_number',
            'state',
            'file_handover_date',
            'file_handover_person',
            'road_tax_payment_date',
            'file_verify',
            'rc_printed_date',
            'rc_rcvd_date',
            'rc_handover_date',
            'payment_amount',
            'payment_balance',
            'payment_mode',
            'payment_date',
            'tull',
            'handover_mode',
            'agent',

            # Used vehicle fields
            'approval_days',
            'approval_date',
            'engine_number',
            'reg_number',
            'slip',
            'service__service_name',
            'fuel',
            'model',
            'paper_rcvd_by',
            'fees_date',
            'fees_amount',
            'billed_amount',
            'rcvd_amount',
            'balance_amount',
            'cgst',
            'sgst',
            'total_gst',
            'gst_invoice'
        ).first()
        return order
