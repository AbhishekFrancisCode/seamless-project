from . import views
from django.contrib import admin
#from django.contrib.auth import views as auth_views
from django.urls import path
from django.views.generic.base import RedirectView

urlpatterns = [
    path('orders', views.orders, name="orders-home-page"),
    path('manage_order', views.manage_order, name="manage_order"),
    path('save_order', views.save_order, name="save-order"),
    path('delete_order', views.delete_order, name="delete-order"),
    path('order_request', views.order_request, name="order_request"),
]