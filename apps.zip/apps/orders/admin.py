from django.contrib import admin
from .models import RTOList

# Register your models here.

admin.site.register(RTOList)
