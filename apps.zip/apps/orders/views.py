from telnetlib import SE
from django.shortcuts import render
from pickle import FALSE
from django.shortcuts import redirect, render
from django.http import HttpResponse
from flask import jsonify

from apps.customer.models import CustomerMaster, DealerMaster
from apps.services.models import Service
from .models import Orders, RTOList
from django.db.models import Count, Sum
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
import json, sys
from datetime import date, datetime
from apps.home.models import Branch

# Create your views here.
# Categories
from .order_management_service import OrderService


@login_required
def orders(request):
    orders_list = Orders.objects.all()
    # category_list = {}
    context = {
        'page_title': 'order List',
        'orders_list': orders_list,
    }
    return render(request, 'order/order_list.html', context)


@login_required
def manage_order(request):
    order = {}
    cust_list = list(CustomerMaster.objects.all())
    dealer_list = list(DealerMaster.objects.all())
    rto_list = list(RTOList.objects.all())
    service_list = list(Service.objects.all())
    order_service = OrderService()
    if request.method == 'GET':
        data = request.GET
        id = ''
        if 'id' in data:
            id = data['id']
        if id.isnumeric() and int(id) > 0:
            order = order_service.get_order(id)

            order['order_date'] = order['order_date'].strftime("%Y-%m-%d") if order['order_date'] is not None else None
            order['file_handover_date'] = order['file_handover_date'].strftime("%Y-%m-%d") if order[
                                                                                                  'file_handover_date'] is not None else None
            order['road_tax_payment_date'] = order['road_tax_payment_date'].strftime("%Y-%m-%d") if order[
                                                                                                        'road_tax_payment_date'] is not None else None
            order['rc_printed_date'] = order['rc_printed_date'].strftime("%Y-%m-%d") if order[
                                                                                            'rc_printed_date'] is not None else None
            order['rc_rcvd_date'] = order['rc_rcvd_date'].strftime("%Y-%m-%d") if order[
                                                                                      'rc_rcvd_date'] is not None else None
            order['rc_handover_date'] = order['rc_handover_date'].strftime("%Y-%m-%d") if order[
                                                                                              'rc_handover_date'] is not None else None
            order['payment_date'] = order['payment_date'].strftime("%Y-%m-%d") if order[
                                                                                      'payment_date'] is not None else None
            order['approval_date'] = order['approval_date'].strftime("%Y-%m-%d") if order[
                                                                                        'approval_date'] is not None else None
            order['fees_date'] = order['fees_date'].strftime("%Y-%m-%d") if order['fees_date'] is not None else None

            print("orderOBJ", order)

    context = {
        'order': order,
        'cust_list': cust_list,
        'dealer_list': dealer_list,
        'rto_list': rto_list,
        'service_list': service_list,
    }
    print("context", context)
    return render(request, 'orders/manage_order.html', context)


@login_required
def save_order(request):
    data = request.POST
    print("data", data)
    resp = {'status': 'failed'}
    try:
        if (data['id']).isnumeric() and int(data['id']) > 0:
            save_order = Orders.objects.get(id=data['id'])
            try:
                if data['order_type'] == '1':
                    print("########UPD NEWWWW")
                    # New order fields

                    # Common fields
                    save_order.order_date = data['order_date']
                    save_order.order_time = data['order_time']
                    save_order.entries = data['entries']
                    save_order.customer_contact_no = data['customer_contact_no']
                    save_order.chassiss_number = data['chassiss_number']
                    save_order.application_number = data['application_number']
                    save_order.remarks = data['remarks']
                    save_order.status = data['status']

                    # New vehicle fields
                    save_order.reg_number = data['reg_number']
                    save_order.state = data['state']
                    save_order.file_handover_date = data['file_handover_date'] if data[
                                                                                      'file_handover_date'] != "" else None
                    save_order.file_handover_person = data['file_handover_person']
                    save_order.road_tax_payment_date = data['road_tax_payment_date'] if data[
                                                                                            'road_tax_payment_date'] != "" else None
                    save_order.file_verify = data['file_verify']
                    save_order.rc_printed_date = data['rc_printed_date'] if data['rc_printed_date'] != "" else None
                    save_order.rc_rcvd_date = data['rc_rcvd_date'] if data['rc_rcvd_date'] != "" else None
                    save_order.rc_handover_date = data['rc_handover_date'] if data['rc_handover_date'] != "" else None
                    save_order.payment_amount = data['payment_amount'] if data['payment_amount'] != "" else 0
                    save_order.payment_balance = data['payment_balance'] if data['payment_balance'] != "" else 0
                    save_order.payment_mode = data['payment_mode']
                    save_order.payment_date = data['payment_date'] if data['payment_date'] != "" else None
                    save_order.tull = data['tull']
                    save_order.handover_mode = data['handover_mode']
                    save_order.agent = data['agent']

                    save_order.save()
                else:
                    # Used order fields

                    # Common fields
                    save_order.order_date = data['order_date']
                    save_order.order_time = data['order_time']
                    save_order.entries = data['entries']
                    save_order.customer_contact_no = data['customer_contact_no']
                    save_order.chassiss_number = data['chassiss_number']
                    save_order.application_number = data['application_number']
                    save_order.remarks = data['remarks']
                    save_order.status = data['status']

                    # Used vehicle fields
                    save_order.approval_days = data['approval_days']
                    save_order.approval_date = data['approval_date'] if data['approval_date'] != "" else None
                    save_order.engine_number = data['engine_number']
                    save_order.reg_number = data['reg_number']
                    save_order.slip = data['slip']
                    save_order.fuel = data['fuel']
                    save_order.model = data['model']
                    save_order.paper_rcvd_by = data['paper_rcvd_by']
                    save_order.fees_date = data['fees_date'] if data['fees_date'] != "" else None
                    save_order.fees_amount = data['fees_amount'] if data['fees_amount'] != "" else 0
                    save_order.billed_amount = data['billed_amount'] if data['billed_amount'] != "" else 0
                    save_order.rcvd_amount = data['rcvd_amount'] if data['rcvd_amount'] != "" else 0
                    save_order.balance_amount = data['balance_amount'] if data['balance_amount'] != "" else 0
                    save_order.cgst = data['cgst']
                    save_order.sgst = data['sgst']
                    save_order.total_gst = data['total_gst']
                    save_order.gst_invoice = data['gst_invoice']

                    save_order.save()
            except Exception as e:
                print("############UPD ext", str(e))

        else:
            try:
                if data['order_type'] == '1':
                    print("####NEWWWW")
                    # New order fields
                    save_order = Orders()

                    # Common fields
                    save_order.order_type = data['order_type']
                    save_order.customer_id = data['customer']
                    save_order.dealer_id = data['dealer']
                    save_order.order_date = data['order_date']
                    save_order.order_time = data['order_time']
                    save_order.entries = data['entries']
                    save_order.customer_contact_no = data['customer_contact_no']
                    save_order.chassiss_number = data['chassiss_number']
                    save_order.application_number = data['application_number']
                    save_order.rto_id = data['rto']
                    save_order.remarks = data['remarks']
                    save_order.status = data['status']

                    # New vehicle fields
                    save_order.reg_number = data['reg_number']
                    save_order.state = data['state']
                    save_order.file_handover_date = data['file_handover_date'] if data[
                                                                                      'file_handover_date'] != "" else None
                    save_order.file_handover_person = data['file_handover_person']
                    save_order.road_tax_payment_date = data['road_tax_payment_date'] if data[
                                                                                            'road_tax_payment_date'] != "" else None
                    save_order.file_verify = data['file_verify']
                    save_order.rc_printed_date = data['rc_printed_date'] if data['rc_printed_date'] != "" else None
                    save_order.rc_rcvd_date = data['rc_rcvd_date'] if data['rc_rcvd_date'] != "" else None
                    save_order.rc_handover_date = data['rc_handover_date'] if data['rc_handover_date'] != "" else None
                    save_order.payment_amount = data['payment_amount'] if data['payment_amount'] != "" else 0
                    save_order.payment_balance = data['payment_balance'] if data['payment_balance'] != "" else 0
                    save_order.payment_mode = data['payment_mode']
                    save_order.payment_date = data['payment_date'] if data['payment_date'] != "" else None
                    save_order.tull = data['tull']
                    save_order.handover_mode = data['handover_mode']
                    save_order.agent = data['agent']

                    save_order.save()
                else:
                    # Used order fields
                    save_order = Orders()

                    # Common fields
                    save_order.order_type = data['order_type']
                    save_order.customer_id = data['customer']
                    save_order.dealer_id = data['dealer']
                    save_order.order_date = data['order_date']
                    save_order.order_time = data['order_time']
                    save_order.entries = data['entries']
                    save_order.customer_contact_no = data['customer_contact_no']
                    save_order.chassiss_number = data['chassiss_number']
                    save_order.application_number = data['application_number']
                    save_order.rto_id = data['rto']
                    save_order.remarks = data['remarks']
                    save_order.status = data['status']

                    # Used vehicle fields
                    save_order.approval_days = data['approval_days']
                    save_order.approval_date = data['approval_date'] if data['approval_date'] != "" else None
                    save_order.engine_number = data['engine_number']
                    save_order.reg_number = data['reg_number']
                    save_order.slip = data['slip']
                    save_order.service_id = data['service_type'] if data['service_type'] != "" else None
                    save_order.fuel = data['fuel']
                    save_order.model = data['model']
                    save_order.paper_rcvd_by = data['paper_rcvd_by']
                    save_order.fees_date = data['fees_date'] if data['fees_date'] != "" else None
                    save_order.fees_amount = data['fees_amount'] if data['fees_amount'] != "" else 0
                    save_order.billed_amount = data['billed_amount'] if data['billed_amount'] != "" else 0
                    save_order.rcvd_amount = data['rcvd_amount'] if data['rcvd_amount'] != "" else 0
                    save_order.balance_amount = data['balance_amount'] if data['balance_amount'] != "" else 0
                    save_order.cgst = data['cgst']
                    save_order.sgst = data['sgst']
                    save_order.total_gst = data['total_gst']
                    save_order.gst_invoice = data['gst_invoice']

                    save_order.save()
            except Exception as e:
                print("####ext", str(e))

        resp['status'] = 'success'
        messages.success(request, 'Order Successfully saved.')
    except Exception as e:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")


@login_required
def delete_order(request):
    data = request.POST
    resp = {'status': ''}
    try:
        Orders.objects.filter(id=data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Order Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")


@login_required
def order_request(request):
    type = request.GET['type']
    filter = request.GET['filter']
    print("ORDER REQST CALLED", request)
    print("type", type)
    print("Filter", filter)
    orders_list = Orders.objects.filter(order_type=type, status=filter).all().values(
        'id',
        'order_type',
        'customer__customer_name',
        'dealer__dealer_name',
        'order_date',
        'order_time',
        'entries',
        'customer_contact_no',
        'chassiss_number',
        'application_number',
        'rto__rto_name',
        'remarks',
        'status',

        # New vehicle fields
        'reg_number',
        'state',
        'file_handover_date',
        'file_handover_person',
        'road_tax_payment_date',
        'file_verify',
        'rc_printed_date',
        'rc_rcvd_date',
        'rc_handover_date',
        'payment_amount',
        'payment_balance',
        'payment_mode',
        'payment_date',
        'tull',
        'handover_mode',
        'agent',

        # Used vehicle fields
        'approval_days',
        'approval_date',
        'engine_number',
        'reg_number',
        'slip',
        'service__service_name',
        'fuel',
        'model',
        'paper_rcvd_by',
        'fees_date',
        'fees_amount',
        'billed_amount',
        'rcvd_amount',
        'balance_amount',
        'cgst',
        'sgst',
        'total_gst',
        'gst_invoice'
    )
    print("ORDER REQST", orders_list)
    # category_list = {}
    context = {
        'page_title': 'Order List',
        'orders_list': orders_list,
        'order_type': type,
        'order_filter': filter
    }
    print("Context", context)
    return render(request, 'orders/order_list.html', context)
