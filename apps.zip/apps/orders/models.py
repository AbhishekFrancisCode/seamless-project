from django.db import models

# Create your models here.
class RTOList(models.Model):
    rto_name = models.CharField(max_length=255,unique=True)
    description = models.CharField(max_length=500,default="")
    status = models.BooleanField(default=True)

    class Meta:
        pass

    def __str__(self) -> str:
        return self.rto_name

class Orders(models.Model):
    # Common for both New & Used
    order_type = models.CharField(max_length=100,default="")
    customer = models.ForeignKey("customer.CustomerMaster", on_delete=models.CASCADE, default=None, null=True, related_name="orders_customer")
    dealer = models.ForeignKey("customer.DealerMaster", on_delete=models.CASCADE, default=None, null=True, related_name="orders_dealer")
    order_date = models.DateField(null=True)
    order_time = models.CharField(max_length=100,default="")
    entries = models.CharField(max_length=245,default="")
    customer_contact_no = models.CharField(max_length=245,unique=True)
    chassiss_number = models.CharField(max_length=245,default="")    
    application_number = models.CharField(max_length=245,default="")
    rto = models.ForeignKey(RTOList, on_delete=models.CASCADE, related_name="orders_rto")
    remarks = models.CharField(max_length=245,default="")
    status = models.CharField(max_length=100,default="")

    # New vehicle fields
    reg_number = models.CharField(max_length=245,default="")
    state = models.CharField(max_length=245,default="")
    file_handover_date = models.DateField(null=True)
    file_handover_person = models.CharField(max_length=245,default="")
    road_tax_payment_date = models.DateField(null=True)
    file_verify = models.CharField(max_length=245,default="NO")
    rc_printed_date = models.DateField(null=True)
    rc_rcvd_date = models.DateField(null=True)
    rc_handover_date = models.DateField(null=True)
    payment_amount = models.CharField(max_length=245,default="")
    payment_balance = models.CharField(max_length=245,default="")
    payment_mode = models.CharField(max_length=245,default="")
    payment_date = models.DateField(null=True)
    tull = models.CharField(max_length=245,default="")
    handover_mode = models.CharField(max_length=245,default="")
    agent = models.CharField(max_length=245,default="")

    # Used vehicle fields
    approval_days = models.CharField(max_length=245,default="")
    approval_date = models.DateField(null=True)      
    engine_number = models.CharField(max_length=245,default="")
    reg_number = models.CharField(max_length=245,default="")    
    slip = models.CharField(max_length=245,default="NO")
    service = models.ForeignKey("services.Service", on_delete=models.CASCADE, default=None, null=True, related_name="orders_service_type")
    fuel = models.CharField(max_length=245,default="")
    model = models.CharField(max_length=245,default="")    
    paper_rcvd_by = models.CharField(max_length=245,default="")
    fees_date = models.DateField(null=True)
    fees_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    billed_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    rcvd_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    balance_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    cgst= models.CharField(max_length=245,default="")
    sgst = models.CharField(max_length=245,default="")
    total_gst = models.CharField(max_length=245,default="")
    gst_invoice = models.CharField(max_length=245,default="")

    class Meta:
        pass

    def __str__(self) -> str:
        return self.customer
