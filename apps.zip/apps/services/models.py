from pyexpat import model
from django.db import models

# Create your models here.


class Service(models.Model):
    service_name = models.CharField(max_length=255,unique=True)
    description = models.CharField(max_length=500,default="")
    status = models.BooleanField(default=True)

    class Meta:
        pass

    def __str__(self) -> str:
        return self.service_name
    
    def get_active_service(self):
        return self.objects.filter(status=1).all()
    
    def get_inactive_service(self):
        return self.objects.filter(status=0).all()

class ServiceBranch(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE, default=None, related_name="service_branch_list")
    branch = models.ForeignKey("home.Branch", on_delete=models.CASCADE, default=None, related_name="service_branch")
    govt_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    service_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        pass

    def __str__(self) -> str:
        return self.branch      

