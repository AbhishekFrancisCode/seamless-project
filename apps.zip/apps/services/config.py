from django.apps import AppConfig


class ServiceConfig(AppConfig):
    name = 'apps.service'
    label = 'apps_service'
