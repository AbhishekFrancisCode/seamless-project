from . import views
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path
from django.views.generic.base import RedirectView

urlpatterns = [
    path('service', views.services, name="service-home-page"),
    path('manage_service', views.manage_service, name="manage_service"),
    path('save_service', views.save_service, name="save-service"),
    path('delete_service', views.delete_service, name="delete-service")
    #path('order_request', views.order_request, name="order-request-page"),
]