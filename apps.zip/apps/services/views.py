from django.shortcuts import render
from pickle import FALSE
from django.shortcuts import redirect, render
from django.http import HttpResponse
from flask import jsonify
from .models import Service, ServiceBranch
from django.db.models import Count, Sum
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
import json, sys
from datetime import date, datetime
from apps.home.models import Branch

# Create your views here.
# Categories
@login_required
def services(request):
    services_list = Service.objects.all()
    # category_list = {}
    context = {
        'page_title': 'Service List',
        'services_list': services_list,
    }
    return render(request, 'service/service_list.html', context)


@login_required
def manage_service(request):
    service = {}
    branch_list = list(Branch.objects.all().values(
        'id', 
        'branch_name', 
        'address_line1', 
        'address_line2', 
        'phone_number', 
        'gst_no', 
        'email', 
        'is_head_office'
    ))
    if request.method == 'GET':
        data = request.GET
        id = ''
        if 'id' in data:
            id = data['id']
        if id.isnumeric() and int(id) > 0:
            service = Service.objects.filter(id=id).values(
                'id',
                'service_name',
                'description',
                'status'
            ).first()
            print("service",service)
            b_list = list(
                ServiceBranch.objects.filter(service_id=service['id']).all().values(
                    "id",
                    "branch__branch_name",
                    "govt_fee",
                    "service_fee"
                ))
            service['has_branch'] = len(b_list)    
            service['branch_details'] = b_list


    context = {
        'service': service,
        'branch_list': branch_list
    }
    print("context",context)
    return render(request, 'service/manage_service.html', context)


@login_required
def save_service(request):
    data = request.POST
    print("data",data)
    resp = {'status': 'failed'}
    try:
        if (data['id']).isnumeric() and int(data['id']) > 0:
            save_service = Service.objects.filter(id=data['id']).update( service_name=data['service_name'],
                                                                          status=data['status'],
                                                                          description=data["description"])     
            if 'branch_id' in data and len(data['branch_id']) > 0:
                service_branch = ServiceBranch.objects.get(service_id=data['id'], branch_id=data['branch_id'])
                service_branch.govt_fee = data['govt_fee']
                service_branch.service_fee = data['service_fee'] 
                service_branch.save()      
        else:
            save_service = Service(service_name=data['service_name'],description=data["description"], status=data['status'])
            save_service.save()

            service_branch = ServiceBranch()
            service_branch.service = save_service
            service_branch.branch_id = data['branch']
            service_branch.govt_fee = data['govt_fee']
            service_branch.service_fee = data['service_fee']
            service_branch.save()

        resp['status'] = 'success'
        messages.success(request, 'Service Successfully saved.')
    except Exception as e:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")


@login_required
def delete_service(request):
    data = request.POST
    resp = {'status': ''}
    try:
        Service.objects.filter(id=data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Service Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
def order_request(request):
    services_list = Service.objects.all()
    # category_list = {}
    context = {
        'page_title': 'Service List',
        'services_list': services_list,
    }
    return render(request, 'orders/order_list.html', context)