from statistics import mode
from django.db import models
from django.forms import CharField

# Create your models here.
class CustomerMaster(models.Model):
    customer_name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=15,default=None,null=True)
    email = models.CharField(max_length=100,default=None,null=True)
    address_line1 = models.CharField(max_length=500,default=None,null=True)
    address_line2 = models.CharField(max_length=500,default=None,null=True)
    active = models.BooleanField(default=True)
    is_blocked = models.BooleanField(default=False)
    remarks = models.CharField(max_length=4000,null=True)

    class Meta:
        pass

    def __str__(self) -> str:
        return self.customer_name

class DealerMaster(models.Model):
    dealer_name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=15,default=None,null=True)
    email = models.CharField(max_length=100,default=None,null=True)
    address_line1 = models.CharField(max_length=500,default=None,null=True)
    address_line2 = models.CharField(max_length=500,default=None,null=True)
    active = models.BooleanField(default=True)
    is_blocked = models.BooleanField(default=False)
    remarks = models.CharField(max_length=4000,null=True)
    
    class Meta:
        pass

    def __str__(self) -> str:
        return self.dealer_name

