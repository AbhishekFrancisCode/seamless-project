from . import views
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path
from django.views.generic.base import RedirectView

urlpatterns = [
    path('customer', views.customer, name="customer-home-page"),
    path('manage_customer', views.manage_customer, name="manage_customer"),
    path('save_customer', views.save_customer, name="save-customer"),
    path('delete_customer', views.delete_customer, name="delete-customer"),
    path('dealer', views.dealer, name="dealer-home-page"),
    path('manage_dealer', views.manage_dealer, name="manage_dealer"),
    path('save_dealer', views.save_dealer, name="save-dealer"),
    path('delete_dealer', views.delete_dealer, name="delete-dealer"),
]