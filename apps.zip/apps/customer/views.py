from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import CustomerMaster,DealerMaster
from django.db.models import Count, Sum
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
import json, sys
from datetime import date, datetime
from django.shortcuts import render
from pickle import FALSE
from django.shortcuts import redirect, render
from django.http import HttpResponse
# Create your views here.
# Create your views here.
# Categories
@login_required
def customer(request):
    customer_list = CustomerMaster.objects.all()
    # category_list = {}
    context = {
        'page_title': 'Customers List',
        'customer_list': customer_list,
    }
    return render(request, 'customer/customer_list.html', context)

@login_required
def manage_customer(request):
    customer = {}
    if request.method == 'GET':
        data = request.GET
        id = ''
        if 'id' in data:
            id = data['id']
        if id.isnumeric() and int(id) > 0:
            customer = CustomerMaster.objects.filter(id=id).first()

    context = {
        'customer': customer
    }
    return render(request, 'customer/manage_customer.html', context)


@login_required
def save_customer(request):
    data = request.POST
    resp = {'status': 'failed'}
    try:
        if (data['id']).isnumeric() and int(data['id']) > 0:
            save_customer = CustomerMaster.objects.filter(id=data['id']). \
                update( 
                    customer_name=data['customer_name'],
                    phone_number=data['phone_number'],
                    email=data["email"],
                    address_line1=data["address_line1"],
                    address_line2=data["address_line2"],
                    active=data["active"],
                    is_blocked=data["is_blocked"],
                    remarks=data["remarks"],
                    )
        else:
            save_customer = CustomerMaster(
                    customer_name=data['customer_name'],
                    phone_number=data['phone_number'],
                    email=data["email"],
                    address_line1=data["address_line1"],
                    address_line2=data["address_line2"],
                    active=data["active"],
                    is_blocked=data["is_blocked"],
                    remarks=data["remarks"],
            )
            save_customer.save()
        resp['status'] = 'success'
        messages.success(request, 'Customer Successfully saved.')
    except Exception as e:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
def delete_customer(request):
    data = request.POST
    resp = {'status': ''}
    try:
        CustomerMaster.objects.filter(id=data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Customer Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
def dealer(request):
    dealer_list = DealerMaster.objects.all()
    # category_list = {}
    context = {
        'page_title': 'Dealer List',
        'dealer_list': dealer_list,
    }
    return render(request, 'dealer/dealer_list.html', context)


@login_required
def manage_dealer(request):
    dealer = {}
    if request.method == 'GET':
        data = request.GET
        id = ''
        if 'id' in data:
            id = data['id']
        if id.isnumeric() and int(id) > 0:
            dealer = DealerMaster.objects.filter(id=id).first()

    context = {
        'dealer': dealer
    }
    return render(request, 'dealer/manage_dealer.html', context)


@login_required
def save_dealer(request):
    data = request.POST
    resp = {'status': 'failed'}
    try:
        if (data['id']).isnumeric() and int(data['id']) > 0:
            save_dealer = DealerMaster.objects.filter(id=data['id']). \
                update( 
                    dealer_name=data['dealer_name'],
                    phone_number=data['phone_number'],
                    email=data["email"],
                    address_line1=data["address_line1"],
                    address_line2=data["address_line2"],
                    active=data["active"],
                    is_blocked=data["is_blocked"],
                    remarks=data["remarks"],
                    )
        else:
            save_dealer = DealerMaster(
                    dealer_name=data['dealer_name'],
                    phone_number=data['phone_number'],
                    email=data["email"],
                    address_line1=data["address_line1"],
                    address_line2=data["address_line2"],
                    active=data["active"],
                    is_blocked=data["is_blocked"],
                    remarks=data["remarks"],
            )
            save_dealer.save()
        resp['status'] = 'success'
        messages.success(request, 'Dealer Successfully saved.')
    except Exception as e:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
def delete_dealer(request):
    data = request.POST
    resp = {'status': ''}
    try:
        DealerMaster.objects.filter(id=data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Dealer Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")