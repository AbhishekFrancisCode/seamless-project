from datetime import datetime
from unicodedata import category
from django.db import models
from django.utils import timezone

# Create your models here.
class Branch(models.Model):
    branch_name = models.CharField(max_length=500,default=None)
    address_line1 = models.CharField(max_length=500,default=None)
    address_line2 = models.CharField(max_length=500,default=None)
    phone_number = models.CharField(max_length=500,default=None)
    gst_no = models.CharField(max_length=500,default=None)
    email = models.CharField(max_length=500,default=None)
    is_head_office = models.IntegerField(default=1) 
    created = models.DateTimeField(default=timezone.now) 
    updated = models.DateTimeField(auto_now=True) 

    def __str__(self):
        return self.branch_name