from pickle import FALSE
from django.shortcuts import redirect, render
from django.http import HttpResponse
from flask import jsonify
# from core.models import Category, Products, Sales, salesItems
from django.db.models import Count, Sum
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
import json, sys
from datetime import date, datetime

from apps.home.models import Branch


# Login
def login_user(request):
    logout(request)
    resp = {"status": 'failed', 'msg': ''}
    username = ''
    password = ''
    if request.POST:
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                resp['status'] = 'success'
            else:
                resp['msg'] = "Incorrect username or password"
        else:
            resp['msg'] = "Incorrect username or password"
    return HttpResponse(json.dumps(resp), content_type='application/json')


# Logout
def logoutuser(request):
    logout(request)
    return redirect('/')


# Create your views here.
@login_required
def home(request):
    now = datetime.now()
    current_year = now.strftime("%Y")
    current_month = now.strftime("%m")
    current_day = now.strftime("%d")
    no_of_applications_not_started = 0
    no_of_applications_in_progress = 0
    no_of_applications_completed = 0
    no_of_applications_hold = 0
    transaction = 0
    today_sales =0
    total_sales = 0
    context = {
        'page_title': 'Home',
        'no_of_applications_not_started': no_of_applications_not_started,
        'no_of_applications_in_progress': no_of_applications_in_progress,
        'no_of_applications_completed': no_of_applications_completed,
        'no_of_applications_hold': no_of_applications_hold,
        'total_sales':total_sales,
    }
    return render(request, 'core/home.html', context)


def about(request):
    context = {
        'page_title': 'About',
    }
    return render(request, 'core/about.html', context)


@login_required
def branch(request):
    branch_list = Branch.objects.all()
    # branch_list = {}
    context = {
        'page_title': 'Branch List',
        'branch': branch_list,
    }
    return render(request, 'branch/branch.html', context)

@login_required
def manage_branch(request):
    branch = {}
    if request.method == 'GET':
        data = request.GET
        id = ''
        if 'id' in data:
            id = data['id']
        if id.isnumeric() and int(id) > 0:
            branch = Branch.objects.filter(id=id).first()

    context = {
        'branch': branch
    }
    return render(request, 'branch/manage_branch.html', context)

@login_required
def save_branch(request):
    data = request.POST
    resp = {'status': 'failed'}
    try:
        if (data['id']).isnumeric() and int(data['id']) > 0:
            save_branch = Branch.objects.filter(id=data['id']).update(branch_name=data['branch_name'],
                                                                          address_line1=data['address_line1'],
                                                                          address_line2=data['address_line2'],
                                                                          phone_number=data['phone_number'],
                                                                          gst_no=data['gst_no'],
                                                                          email=data['email'],
                                                                          is_head_office=data['is_head_office'])
        else:
            save_branch = Branch(branch_name=data['branch_name'],
                                                                          address_line1=data['address_line1'],
                                                                          address_line2=data['address_line2'],
                                                                          phone_number=data['phone_number'],
                                                                          gst_no=data['gst_no'],
                                                                          email=data['email'],
                                                                          is_head_office=data['is_head_office'])
            save_branch.save()
        resp['status'] = 'success'
        messages.success(request, 'Branch details Successfully saved.')
    except Exception as e:
        resp['status'] = 'failed'
        resp['error'] = str(e)
    return HttpResponse(json.dumps(resp), content_type="application/json")

@login_required
def delete_branch(request):
    data = request.POST
    resp = {'status': ''}
    try:
        Branch.objects.filter(id=data['id']).delete()
        resp['status'] = 'success'
        messages.success(request, 'Branch Successfully deleted.')
    except:
        resp['status'] = 'failed'
    return HttpResponse(json.dumps(resp), content_type="application/json")